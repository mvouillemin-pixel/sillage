/* Présentation des sports sur la page d'accueil : quatre familles, trois états.

   Ce module ne fait que LIRE le catalogue canonique (debut/catalogue.ts) et ne
   modifie ni le moteur, ni le catalogue, ni les statuts qui y sont déclarés.

   Contradiction connue dans le dépôt : le catalogue déclare le néoprène (surf,
   eau libre, triathlon, kitesurf, wingfoil, plongée) « personnalise », alors que
   la feuille de route de l'accueil situe la bêta néoprène au printemps 2027.
   Décision produit : sur l'accueil, seuls le ski et le snowboard sont annoncés
   « Disponible ». Les sports listés dans NON_ANNONCES sont présentés « En
   développement » tant que cette décision n'est pas révisée. */

import type { FamilleDebut } from "./bibliotheque";
import { SPORTS_DEBUT, type SportDebut } from "./debut";

export type EtatAccueil = "disponible" | "developpement" | "prochain";
export type FamilleAccueil = "eau" | "raquette_balle" | "plein_air" | "forme_combat";

export const FAMILLES_ACCUEIL: readonly FamilleAccueil[] = [
  "eau",
  "raquette_balle",
  "plein_air",
  "forme_combat",
];

/** Regroupement d'affichage des six familles du catalogue en quatre. */
const FAMILLE_DE: Record<FamilleDebut, FamilleAccueil> = {
  eau: "eau",
  raquette: "raquette_balle",
  ballon_balle: "raquette_balle",
  glisse: "plein_air",
  plein_air: "plein_air",
  forme_combat: "forme_combat",
};

const NON_ANNONCES = new Set(["surf", "eau_libre", "triathlon", "kitesurf", "wingfoil", "plongee"]);

export interface SportAccueil {
  id: string;
  /** Clé du nom du sport dans le dictionnaire « Je commence » (`sport.<id>`). */
  cle: string;
  famille: FamilleAccueil;
  etat: EtatAccueil;
  /** Un guide débutant vérifié existe (contenu éditorial, pas une recommandation). */
  guide: boolean;
}

export function etatAccueil(sport: SportDebut): EtatAccueil {
  if (sport.statut === "personnalise" && sport.fitDisponible && !NON_ANNONCES.has(sport.id)) {
    return "disponible";
  }
  if (sport.statut === "personnalise" || sport.statut === "guide") return "developpement";
  return "prochain";
}

const ORDRE_ETAT: Record<EtatAccueil, number> = { disponible: 0, developpement: 1, prochain: 2 };

/** Sports groupés par famille d'accueil ; disponibles d'abord, ordre du catalogue sinon. */
export function sportsParFamille(): Record<FamilleAccueil, SportAccueil[]> {
  const groupes: Record<FamilleAccueil, SportAccueil[]> = {
    eau: [],
    raquette_balle: [],
    plein_air: [],
    forme_combat: [],
  };
  for (const s of SPORTS_DEBUT) {
    groupes[FAMILLE_DE[s.famille]].push({
      id: s.id,
      cle: s.cle,
      famille: FAMILLE_DE[s.famille],
      etat: etatAccueil(s),
      guide: s.statut === "guide" && s.parcoursInteractif,
    });
  }
  for (const f of FAMILLES_ACCUEIL) {
    groupes[f].sort((a, b) => ORDRE_ETAT[a.etat] - ORDRE_ETAT[b.etat]);
  }
  return groupes;
}

/** Photos par sport (public/photos), la première s'affiche d'abord. Un sport sans photo
    n'en affiche aucune : on n'illustre jamais un sport par l'image d'un autre. Les
    dimensions réservent la place avant le chargement (pas de décalage de mise en page).
    Textes alternatifs en EN et FR ; les autres langues retombent sur l'anglais.
    Source des images ajoutées : Pexels (licence à confirmer avant la production). */
export interface PhotoSport {
  src: string;
  largeur: number;
  hauteur: number;
  alt: { en: string; fr: string };
}

export const PHOTOS_SPORT: Record<string, PhotoSport[]> = {
  ski: [
    {
      src: "/photos/ski-piste.jpg",
      largeur: 594,
      hauteur: 336,
      alt: {
        en: "A skier carving on a groomed slope",
        fr: "Un skieur qui carve sur une piste damée",
      },
    },
    {
      src: "/photos/ski-telesiege.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "Skis seen from a chairlift above a snowy forest",
        fr: "Des skis vus depuis un télésiège au-dessus d'une forêt enneigée",
      },
    },
    {
      src: "/photos/ski-moniteur.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "A ski instructor in red carving on a groomed slope",
        fr: "Un moniteur de ski en rouge qui carve sur une piste damée",
      },
    },
  ],
  snowboard: [
    {
      src: "/photos/snowboard-piste.jpg",
      largeur: 678,
      hauteur: 452,
      alt: {
        en: "A snowboarder riding a snowy slope",
        fr: "Un snowboardeur qui descend une pente enneigée",
      },
    },
    {
      src: "/photos/snowboard-crete.jpg",
      largeur: 560,
      hauteur: 843,
      alt: {
        en: "A snowboarder standing on a ridge under a blue sky",
        fr: "Un snowboardeur debout sur une crête sous un ciel bleu",
      },
    },
    {
      src: "/photos/snowboard-virage.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "A snowboarder carving a turn in fresh snow",
        fr: "Un snowboardeur prend un virage dans la neige fraîche",
      },
    },
    {
      src: "/photos/snowboard-rouge.jpg",
      largeur: 560,
      hauteur: 699,
      alt: {
        en: "A snowboarder in red on a wide slope",
        fr: "Une snowboardeuse en rouge sur une large piste",
      },
    },
    {
      src: "/photos/snowboard-jaune.jpg",
      largeur: 560,
      hauteur: 747,
      alt: {
        en: "A snowboarder in a yellow jacket above a snowy forest",
        fr: "Une snowboardeuse en veste jaune au-dessus d'une forêt enneigée",
      },
    },
  ],
  surf: [
    {
      src: "/photos/surf-vague.jpg",
      largeur: 678,
      hauteur: 452,
      alt: { en: "A surfer riding a wave", fr: "Un surfeur sur une vague" },
    },
    {
      src: "/photos/surf-attente.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "Surfers waiting in the water at sunset",
        fr: "Des surfeurs qui attendent dans l'eau au coucher du soleil",
      },
    },
    {
      src: "/photos/surf-planches.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "Two surfboards leaning against a wall",
        fr: "Deux planches de surf appuyées contre un mur",
      },
    },
    {
      src: "/photos/surf-vague-aerien.jpg",
      largeur: 560,
      hauteur: 560,
      alt: {
        en: "Three surfers on a wave, seen from above",
        fr: "Trois surfeurs sur une vague, vus du dessus",
      },
    },
    {
      src: "/photos/surf-arc-en-ciel.jpg",
      largeur: 560,
      hauteur: 700,
      alt: {
        en: "Surfers in turquoise water under a rainbow",
        fr: "Des surfeurs dans une eau turquoise sous un arc-en-ciel",
      },
    },
    {
      src: "/photos/surf-crepuscule.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "A lone surfer among waves at dusk",
        fr: "Un surfeur seul parmi les vagues au crépuscule",
      },
    },
  ],
  eau_libre: [
    {
      src: "/photos/nage-eau-libre.jpg",
      largeur: 612,
      hauteur: 343,
      alt: {
        en: "A swimmer in a wetsuit swimming in open water",
        fr: "Un nageur en combinaison qui nage en eau libre",
      },
    },
    {
      src: "/photos/eau-libre-large.jpg",
      largeur: 720,
      hauteur: 513,
      alt: {
        en: "A swimmer in open water, seen from above",
        fr: "Un nageur en eau libre, vu du dessus",
      },
    },
  ],
  natation_piscine: [
    {
      src: "/photos/natation-dos.jpg",
      largeur: 720,
      hauteur: 480,
      alt: { en: "A backstroke swimmer in a pool", fr: "Un nageur en dos crawlé dans une piscine" },
    },
    {
      src: "/photos/natation-dessus.jpg",
      largeur: 560,
      hauteur: 995,
      alt: {
        en: "A swimmer seen from above in a pool lane",
        fr: "Une nageuse vue du dessus dans un couloir de piscine",
      },
    },
    {
      src: "/photos/natation-papillon.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "A butterfly swimmer in a competition pool",
        fr: "Une nageuse de papillon dans un bassin de compétition",
      },
    },
  ],
  wingfoil: [
    {
      src: "/photos/wingfoil-saut.jpg",
      largeur: 720,
      hauteur: 456,
      alt: {
        en: "A wing foiler in the air above turquoise water",
        fr: "Un wingfoileur en vol au-dessus d'une eau turquoise",
      },
    },
    {
      src: "/photos/wingfoil-plage.jpg",
      largeur: 720,
      hauteur: 480,
      alt: { en: "A wing foiler on a windy beach", fr: "Un wingfoileur sur une plage venteuse" },
    },
  ],
  kitesurf: [
    {
      src: "/photos/kitesurf-sortie.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "A kitesurfer walking out of the water with a board and control bar",
        fr: "Un kitesurfeur sort de l'eau avec sa planche et sa barre",
      },
    },
  ],
  tennis: [
    {
      src: "/photos/tennis-service.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "A player about to serve with a ball and racket on a clay court",
        fr: "Un joueur s'apprête à servir avec une balle et une raquette sur terre battue",
      },
    },
    {
      src: "/photos/tennis-balle-raquette.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "A player bouncing a ball on a racket on a clay court",
        fr: "Une joueuse fait rebondir une balle sur sa raquette sur terre battue",
      },
    },
    {
      src: "/photos/tennis-score.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "A tennis scoreboard on a clay court",
        fr: "Un tableau de score de tennis sur terre battue",
      },
    },
    {
      src: "/photos/tennis-court-bleu.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "A racket and tennis balls on a blue court",
        fr: "Une raquette et des balles de tennis sur un court bleu",
      },
    },
    {
      src: "/photos/tennis-manche.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "Hands gripping a tennis racket handle",
        fr: "Deux mains serrées sur le manche d'une raquette de tennis",
      },
    },
    {
      src: "/photos/tennis-balles-filet.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "Tennis balls on a court next to the net",
        fr: "Des balles de tennis sur un court près du filet",
      },
    },
  ],
  padel: [
    {
      src: "/photos/padel-raquette.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "A padel racket and ball beside the net on a blue court",
        fr: "Une raquette de padel et une balle près du filet sur un terrain bleu",
      },
    },
  ],
  badminton: [
    {
      src: "/photos/badminton-volant-tete.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "A player with a shuttlecock above their head and a racket in hand",
        fr: "Une joueuse avec un volant au-dessus de la tête et une raquette à la main",
      },
    },
    {
      src: "/photos/badminton-halle-nb.jpg",
      largeur: 560,
      hauteur: 995,
      alt: {
        en: "A large indoor badminton hall, in black and white",
        fr: "Une grande salle de badminton, en noir et blanc",
      },
    },
    {
      src: "/photos/badminton-volant-raquette.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "A hand holding a shuttlecock on a badminton racket",
        fr: "Une main tenant un volant sur une raquette de badminton",
      },
    },
  ],
  football: [
    {
      src: "/photos/football-duel.jpg",
      largeur: 720,
      hauteur: 405,
      alt: {
        en: "Two players challenging for the ball on a grass pitch",
        fr: "Deux joueurs se disputent le ballon sur un terrain en herbe",
      },
    },
    {
      src: "/photos/football-terrain-rue.jpg",
      largeur: 560,
      hauteur: 700,
      alt: {
        en: "Players contesting an orange ball on a street court",
        fr: "Des joueurs se disputent un ballon orange sur un terrain de rue",
      },
    },
  ],
  handball: [
    {
      src: "/photos/handball-match-salle.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "A goalkeeper diving as a shot flies in an indoor handball match",
        fr: "Une gardienne plonge sur un tir lors d'un match de handball en salle",
      },
    },
    {
      src: "/photos/handball-lancer.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "A young player raising a handball above his head",
        fr: "Un jeune joueur lève un ballon de handball au-dessus de sa tête",
      },
    },
    {
      src: "/photos/handball-ballon-main.jpg",
      largeur: 560,
      hauteur: 746,
      alt: { en: "A hand holding a handball", fr: "Une main tenant un ballon de handball" },
    },
  ],
  volleyball: [
    {
      src: "/photos/volley-plage-smash.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "A player jumping to hit the ball above a beach volleyball net",
        fr: "Une joueuse saute pour frapper le ballon au-dessus d'un filet de beach-volley",
      },
    },
    {
      src: "/photos/volley-salle-match.jpg",
      largeur: 560,
      hauteur: 838,
      alt: {
        en: "Players in an indoor volleyball rally",
        fr: "Des joueurs pendant un échange de volley en salle",
      },
    },
    {
      src: "/photos/volley-plage-plongeon.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "A player diving for the ball on a beach volleyball court",
        fr: "Un joueur plonge pour le ballon sur un terrain de beach-volley",
      },
    },
    {
      src: "/photos/volley-service.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "A volleyball player serving in a gym",
        fr: "Une joueuse de volley au service dans un gymnase",
      },
    },
  ],
  velo: [
    {
      src: "/photos/velo-front-de-mer.jpg",
      largeur: 720,
      hauteur: 432,
      alt: {
        en: "Road cyclists riding along a palm-lined seafront",
        fr: "Des cyclistes sur route le long d'un front de mer bordé de palmiers",
      },
    },
    {
      src: "/photos/velo-pause-nb.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "Road cyclists talking, in black and white",
        fr: "Des cyclistes sur route en discussion, en noir et blanc",
      },
    },
    {
      src: "/photos/velo-campagne.jpg",
      largeur: 560,
      hauteur: 746,
      alt: {
        en: "A group of cyclists riding on a country road",
        fr: "Un groupe de cyclistes sur une route de campagne",
      },
    },
    {
      src: "/photos/velo-contre-jour.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "Cyclists stopped in a city street in warm backlight",
        fr: "Des cyclistes à l'arrêt dans une rue de ville, en contre-jour chaud",
      },
    },
  ],
  randonnee: [
    {
      src: "/photos/randonnee-racines.jpg",
      largeur: 560,
      hauteur: 995,
      alt: {
        en: "Two hikers climbing a forest trail covered in roots",
        fr: "Deux randonneurs montent un sentier de forêt couvert de racines",
      },
    },
    {
      src: "/photos/randonnee-sentier-pins.jpg",
      largeur: 560,
      hauteur: 839,
      alt: {
        en: "Four hikers walking up a dirt trail among pine trees",
        fr: "Quatre randonneurs montent un sentier de terre parmi les pins",
      },
    },
    {
      src: "/photos/randonnee-groupe-automne.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "A group of hikers climbing through autumn ferns",
        fr: "Un groupe de randonneurs monte à travers des fougères d'automne",
      },
    },
    {
      src: "/photos/randonnee-foret-batons.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "A hiker with a backpack and trekking poles in a forest",
        fr: "Une randonneuse avec un sac à dos et des bâtons dans une forêt",
      },
    },
  ],
  skateboard: [
    {
      src: "/photos/skate-pieds.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "A skateboarder's feet flipping a board",
        fr: "Les pieds d'un skateur qui fait tourner sa planche",
      },
    },
    {
      src: "/photos/skate-module.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "A skateboarder jumping off a ledge in a skatepark",
        fr: "Un skateur saute depuis un module dans un skatepark",
      },
    },
    {
      src: "/photos/skate-place-nb.jpg",
      largeur: 560,
      hauteur: 840,
      alt: {
        en: "A skateboarder riding across a city square, in black and white",
        fr: "Un skateur traverse une place en ville, en noir et blanc",
      },
    },
    {
      src: "/photos/skate-amies.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "A skateboarder reaching out to a friend at a skatepark",
        fr: "Une skateuse tend la main à une amie dans un skatepark",
      },
    },
  ],
  course: [
    {
      src: "/photos/course-piste-rouge.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "A runner on a red athletics track",
        fr: "Un coureur sur une piste d'athlétisme rouge",
      },
    },
    {
      src: "/photos/course-quai.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "Two joggers running along a waterfront boardwalk",
        fr: "Deux joggeurs courent le long d'une promenade au bord de l'eau",
      },
    },
    {
      src: "/photos/course-piste-bleue.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "Runners on a blue track in the evening",
        fr: "Des coureurs sur une piste bleue en soirée",
      },
    },
    {
      src: "/photos/course-route-soir.jpg",
      largeur: 560,
      hauteur: 995,
      alt: {
        en: "A runner on a tree-lined road at sunset",
        fr: "Une coureuse sur une route bordée d'arbres au coucher du soleil",
      },
    },
    {
      src: "/photos/course-silhouette.jpg",
      largeur: 560,
      hauteur: 995,
      alt: {
        en: "A runner in silhouette against the sky",
        fr: "Un coureur en silhouette contre le ciel",
      },
    },
  ],
  judo: [
    {
      src: "/photos/judo-sol.jpg",
      largeur: 560,
      hauteur: 995,
      alt: {
        en: "Two judokas working on a hold on the mat",
        fr: "Deux judokas travaillent une immobilisation sur le tatami",
      },
    },
    {
      src: "/photos/judo-projection.jpg",
      largeur: 720,
      hauteur: 592,
      alt: {
        en: "A judoka lifting an opponent in a throw",
        fr: "Un judoka projette son adversaire",
      },
    },
    {
      src: "/photos/judo-corps-a-corps.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "Two judokas grappling on a yellow mat",
        fr: "Deux judokas au corps à corps sur un tatami jaune",
      },
    },
    {
      src: "/photos/judo-salut.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "Three people kneeling on a judo mat",
        fr: "Trois personnes agenouillées sur un tatami de judo",
      },
    },
  ],
  boxe: [
    {
      src: "/photos/boxe-sparring-nb.jpg",
      largeur: 720,
      hauteur: 480,
      alt: {
        en: "Two boxers in headgear sparring, in black and white",
        fr: "Deux boxeurs casqués à l'entraînement, en noir et blanc",
      },
    },
  ],
};
