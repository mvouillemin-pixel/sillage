import { Link } from "@tanstack/react-router";
import { Check, Clock, Hammer } from "lucide-react";
import { useMemo, useState, type CSSProperties } from "react";

import { Section } from "@/components/marketing/Sections";
import { CHEMIN_DEBUT, makeTD, type LangDebut } from "@/lib/sillage/debut";
import type { Lang } from "@/lib/sillage/i18n";
import type { TM } from "@/lib/sillage/marketing-i18n";
import {
  FAMILLES_ACCUEIL,
  PHOTOS_SPORT,
  sportsParFamille,
  type EtatAccueil,
  type FamilleAccueil,
  type SportAccueil,
} from "@/lib/sillage/accueil-sports";

import { PhotosSport } from "./PhotosSport";
import "./sports.css";

const CLE_FAMILLE: Record<FamilleAccueil, string> = {
  eau: "water",
  raquette_balle: "racketBall",
  plein_air: "outdoor",
  forme_combat: "fitness",
};

const ICONE: Record<EtatAccueil, typeof Check> = {
  disponible: Check,
  developpement: Hammer,
  prochain: Clock,
};

/** Un état n'est jamais porté par la couleur seule : icône et libellé l'accompagnent. */
const TON: Record<EtatAccueil, string> = {
  disponible: "border-primary/40 bg-primary/10 text-primary",
  developpement: "border-border bg-muted text-foreground",
  prochain: "border-dashed border-border text-muted-foreground",
};

function Pastille({ etat, tm }: { etat: EtatAccueil; tm: TM }) {
  const Icone = ICONE[etat];
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[0.6875rem] font-medium ${TON[etat]}`}
    >
      <Icone className="size-3" aria-hidden />
      {tm(`sports.etat.${etat}`)}
    </span>
  );
}

/** « What do you want to start? » : familles, sports, et ce que chaque état permet.
    Seul un sport « Disponible » mène à l'outil de taille. Les autres restent
    informatifs : aucun parcours de recommandation factice. */
export function DecouverteSports({ lang, tm }: { lang: Lang; tm: TM }) {
  const groupes = useMemo(() => sportsParFamille(), []);
  const td = useMemo(() => makeTD(lang), [lang]);
  const [famille, setFamille] = useState<FamilleAccueil>("plein_air");
  const [choix, setChoix] = useState("ski");

  const sports = groupes[famille];
  const sport: SportAccueil | undefined = sports.find((s) => s.id === choix) ?? sports[0];

  const changerFamille = (f: FamilleAccueil) => {
    setFamille(f);
    setChoix(groupes[f][0]?.id ?? "");
  };

  const cheminDebut = (CHEMIN_DEBUT[lang as LangDebut] ?? CHEMIN_DEBUT.en) as "/en/start";

  return (
    <Section id="sports">
      <p className="eyebrow">{tm("sports.eyebrow")}</p>
      <h2 className="mt-3 font-serif text-3xl text-foreground">{tm("stage.question")}</h2>
      <p className="mt-3 max-w-xl text-muted-foreground">{tm("sports.sous")}</p>

      <div
        role="group"
        aria-label={tm("sports.familles")}
        className="mt-10 grid grid-cols-2 gap-2.5 md:grid-cols-4"
      >
        {FAMILLES_ACCUEIL.map((f) => (
          <button
            key={f}
            type="button"
            aria-pressed={f === famille}
            onClick={() => changerFamille(f)}
            className="carte-pressable carte-vivante min-h-11 rounded-2xl border border-border bg-card px-4 py-3 text-left text-sm text-foreground aria-pressed:border-primary aria-pressed:bg-mint/60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
          >
            {tm(`stage.fam.${CLE_FAMILLE[f]}`)}
          </button>
        ))}
      </div>

      <div className="mt-8 grid gap-6 md:grid-cols-[minmax(0,1fr)_minmax(0,22rem)] md:gap-10">
        <ul
          key={famille}
          role="list"
          aria-label={tm("sports.liste")}
          className="grid content-start gap-2.5 sm:grid-cols-2"
        >
          {sports.map((s, i) => (
            <li key={s.id} className="sp-entree" style={{ "--i": i } as CSSProperties}>
              <button
                type="button"
                aria-pressed={sport?.id === s.id}
                onClick={() => setChoix(s.id)}
                className="carte-pressable carte-vivante flex min-h-11 w-full flex-wrap items-center justify-between gap-2 rounded-2xl border border-border bg-card px-4 py-3 text-left text-sm text-foreground aria-pressed:border-primary aria-pressed:shadow-[var(--shadow-diffuse)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
              >
                <span>{td(s.cle)}</span>
                <Pastille etat={s.etat} tm={tm} />
              </button>
            </li>
          ))}
        </ul>

        {sport ? (
          <div
            key={sport.id}
            aria-live="polite"
            className="sp-detail overflow-hidden rounded-2xl border border-border bg-card"
          >
            {PHOTOS_SPORT[sport.id] ? (
              <PhotosSport photos={PHOTOS_SPORT[sport.id]!} lang={lang} tm={tm} />
            ) : null}
            <div className="p-6">
              <div className="flex flex-wrap items-center gap-3">
                <p className="font-serif text-2xl text-foreground">{td(sport.cle)}</p>
                <Pastille etat={sport.etat} tm={tm} />
              </div>
              <p className="mt-3 text-sm text-muted-foreground">
                {sport.guide ? tm("sports.detail.guide") : tm(`sports.detail.${sport.etat}`)}
              </p>
              {sport.etat === "disponible" ? (
                <Link
                  to="/app"
                  className="btn-primaire mt-5 inline-flex min-h-11 items-center rounded-[24px] bg-primary px-6 py-3 text-sm font-medium text-primary-foreground"
                >
                  {tm("hero.ctas.c1")}
                </Link>
              ) : sport.guide ? (
                <Link
                  to={cheminDebut}
                  className="btn-contour mt-5 inline-flex min-h-11 items-center rounded-[24px] border border-primary px-5 py-2.5 text-sm font-medium text-primary"
                >
                  {tm("sports.action.guide")}
                </Link>
              ) : null}
            </div>
          </div>
        ) : null}
      </div>
    </Section>
  );
}
