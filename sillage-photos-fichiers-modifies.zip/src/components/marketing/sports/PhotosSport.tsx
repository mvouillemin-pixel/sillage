import { useState } from "react";

import type { Lang } from "@/lib/sillage/i18n";
import type { TM } from "@/lib/sillage/marketing-i18n";
import type { PhotoSport } from "@/lib/sillage/accueil-sports";

/** Photos d'un sport : une seule image est chargée à la fois (chargement différé),
    les autres à la demande. Plusieurs photos : sélecteur à cibles tactiles de 44 px. */
export function PhotosSport({ photos, lang, tm }: { photos: PhotoSport[]; lang: Lang; tm: TM }) {
  const [index, setIndex] = useState(0);
  const photo = photos[index] ?? photos[0];
  if (!photo) return null;

  return (
    <div>
      <div className="sp-photo aspect-[3/2] w-full overflow-hidden bg-muted">
        <img
          key={photo.src}
          src={photo.src}
          width={photo.largeur}
          height={photo.hauteur}
          alt={lang === "fr" ? photo.alt.fr : photo.alt.en}
          loading="lazy"
          decoding="async"
          className="size-full object-cover"
        />
      </div>
      {photos.length > 1 ? (
        <div className="flex items-center gap-1 px-4 pt-1" role="group" aria-label="Photos">
          {photos.map((p, i) => (
            <button
              key={p.src}
              type="button"
              aria-label={`${tm("sports.photoLabel")} ${i + 1} ${tm("sports.photoSur")} ${photos.length}`}
              aria-pressed={i === index}
              onClick={() => setIndex(i)}
              className="group flex h-11 min-w-11 flex-1 items-center justify-center focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-ring"
            >
              <span
                className="h-0.5 w-full rounded-full bg-border transition-colors group-aria-pressed:bg-primary"
                aria-hidden
              />
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}
