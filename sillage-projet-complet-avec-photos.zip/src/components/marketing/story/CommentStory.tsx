import { useEffect, useRef, useState } from "react";

import {
  CadrePhone,
  MaquetteEtape1,
  MaquetteEtape2,
  MaquetteEtape3,
  MaquetteEtape4,
} from "@/components/marketing/Cadres";
import { Reveal } from "@/components/motion/Reveal";
import { useReducedMotion, useScrollProgress } from "@/lib/motion";
import type { T } from "@/lib/sillage/i18n";
import type { TM } from "@/lib/sillage/marketing-i18n";

import "./story.css";

/** « How it works » guidé par le scroll.
    Bureau : les étapes défilent à gauche, un téléphone collant à droite change de
    maquette avec l'étape lue. Mobile et tablette : liste verticale, chaque maquette
    apparaît sous son étape. Le défilement reste natif : rien n'est épinglé longuement
    ni détourné. Les quatre étapes et leurs textes sont toujours dans le DOM. */
export function CommentStory({ t, tm }: { t: T; tm: TM }) {
  const reduit = useReducedMotion();
  const racine = useRef<HTMLOListElement | null>(null);
  const [actif, setActif] = useState(0);

  const etapes = [
    { titre: tm("comment.s1t"), texte: tm("comment.s1d"), vue: <MaquetteEtape1 t={t} /> },
    { titre: tm("comment.s2t"), texte: tm("comment.s2d"), vue: <MaquetteEtape2 t={t} /> },
    { titre: tm("comment.s3t"), texte: tm("comment.s3d"), vue: <MaquetteEtape3 t={t} /> },
    { titre: tm("comment.s4t"), texte: tm("comment.s4d"), vue: <MaquetteEtape4 t={t} /> },
  ];

  useScrollProgress(racine, !reduit);

  /* L'étape qui croise la bande centrale de l'écran est l'étape lue. */
  useEffect(() => {
    const liste = racine.current;
    if (!liste || typeof IntersectionObserver === "undefined") return;
    const observer = new IntersectionObserver(
      (entrees) => {
        for (const e of entrees) {
          if (e.isIntersecting) setActif(Number(e.target.getAttribute("data-etape")));
        }
      },
      { rootMargin: "-40% 0px -40% 0px" },
    );
    liste.querySelectorAll("[data-etape]").forEach((li) => observer.observe(li));
    return () => observer.disconnect();
  }, []);

  return (
    <div className="mt-12 lg:grid lg:grid-cols-[minmax(0,1fr)_18rem] lg:gap-20">
      <ol ref={racine} className="story-liste relative grid gap-14 pl-9 lg:gap-0">
        <span className="story-rail" aria-hidden />
        {etapes.map((e, i) => (
          <li
            key={e.titre}
            data-etape={i}
            data-actif={i === actif}
            className="story-etape relative grid content-center gap-6 lg:min-h-[58vh]"
          >
            <span className="story-repere" data-atteint={i <= actif} aria-hidden />
            <div>
              <p className="eyebrow">
                <span className="font-mono text-primary">0{i + 1}</span>
                <span className="text-muted-foreground"> / 04</span>
              </p>
              <h3 className="mt-2 font-serif text-2xl text-foreground">{e.titre}</h3>
              <p className="mt-3 max-w-md text-muted-foreground">{e.texte}</p>
            </div>
            <Reveal className="lg:hidden">
              <CadrePhone label={e.titre}>{e.vue}</CadrePhone>
            </Reveal>
          </li>
        ))}
      </ol>

      {/* Téléphone collant (bureau) : doublon visuel des maquettes, masqué aux lecteurs d'écran. */}
      <div className="hidden lg:block" aria-hidden>
        <div className="sticky top-28">
          <div className="story-scene">
            <CadrePhone>
              <div className="story-pile">
                {etapes.map((e, i) => (
                  <div key={e.titre} className="story-vue" data-actif={i === actif}>
                    {e.vue}
                  </div>
                ))}
              </div>
            </CadrePhone>
          </div>
        </div>
      </div>
    </div>
  );
}
