/* Scènes de la séquence d'ouverture. Chaque scène est purement visuelle :
   aucune donnée de recommandation n'est calculée ni inventée ici. Les libellés
   viennent des dictionnaires existants (zones, étapes) ou de `stage.*`. */

import { Dumbbell, Mountain, Volleyball, Waves } from "lucide-react";
import { Fragment, type CSSProperties, type ReactNode } from "react";

import { CadrePhone, CarteResultatDemo } from "@/components/marketing/Cadres";
import type { T } from "@/lib/sillage/i18n";
import type { TM } from "@/lib/sillage/marketing-i18n";

export type EtatScene = "idle" | "active" | "past";

export function Scene({
  etat,
  finale,
  children,
}: {
  etat: EtatScene;
  finale?: boolean;
  children: ReactNode;
}) {
  return (
    <div className="hs-scene" data-state={etat} data-final={finale ? "" : undefined}>
      {children}
    </div>
  );
}

/** Index d'échelonnement lu par la feuille de style (`--i`). */
const rang = (i: number) => ({ "--i": i }) as CSSProperties;

function Legende({ numero, texte }: { numero: string; texte: string }) {
  return (
    <p className="hs-rise eyebrow mb-4 flex items-center gap-2" style={rang(0)}>
      <span className="font-mono text-primary">{numero}</span>
      <span>{texte}</span>
    </p>
  );
}

/* 01 : « What do you want to start? » et les quatre familles. */
export function SceneQuestion({ tm }: { tm: TM }) {
  const mots = tm("stage.question").split(" ");
  const familles = [
    { cle: "water", Icone: Waves },
    { cle: "racketBall", Icone: Volleyball },
    { cle: "outdoor", Icone: Mountain },
    { cle: "fitness", Icone: Dumbbell },
  ] as const;
  return (
    <>
      <p className="font-serif text-[2rem] leading-[1.15] text-foreground md:text-4xl">
        {mots.map((mot, i) => (
          <Fragment key={`${mot}-${i}`}>
            <span className="hs-mot">
              <span style={rang(i)}>{mot}</span>
            </span>{" "}
          </Fragment>
        ))}
      </p>
      <ul className="mt-7 grid grid-cols-2 gap-2.5">
        {familles.map(({ cle, Icone }, i) => (
          <li
            key={cle}
            className="hs-rise hs-famille flex min-h-11 items-center gap-2.5 rounded-2xl border border-border bg-card/80 px-3 py-2.5 text-sm text-foreground"
            data-cible={cle === "outdoor" ? "" : undefined}
            style={rang(mots.length + i)}
          >
            <Icone className="size-4 shrink-0 text-primary" aria-hidden />
            <span>{tm(`stage.fam.${cle}`)}</span>
          </li>
        ))}
      </ul>
    </>
  );
}

/* 02 : un sport concret, et ce qu'il implique. Pièces = sous-volets de config.ts (volet B). */
export function SceneSport({ tm }: { tm: TM }) {
  const pieces = ["jacket", "pants", "layer", "suit"] as const;
  return (
    <>
      <Legende numero="01" texte={tm("comment.s1t")} />
      <div className="hs-rise flex flex-wrap items-center gap-3" style={rang(1)}>
        <p className="font-serif text-3xl text-foreground">{tm("stage.sport")}</p>
        <span className="rounded-full border border-primary/40 bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary">
          {tm("stage.available")}
        </span>
      </div>
      <ol className="mt-6 grid gap-2">
        {pieces.map((cle, i) => (
          <li
            key={cle}
            className="hs-rise flex items-center gap-3 rounded-2xl border border-border bg-card/80 px-3.5 py-3 text-sm text-foreground"
            style={rang(i + 3)}
          >
            <span className="font-mono text-xs text-muted-foreground">0{i + 1}</span>
            <span>{tm(`stage.pieces.${cle}`)}</span>
          </li>
        ))}
      </ol>
    </>
  );
}

/* 03 : l'utilisateur. Mesures = zones réelles de l'outil ; aucune valeur inventée. */
export function SceneVous({ t, tm }: { t: T; tm: TM }) {
  const zones = [t("zones.c.label"), t("zones.wa.label"), t("zones.hp.label")];
  return (
    <>
      <Legende numero="02" texte={tm("comment.s3t")} />
      <ul className="grid gap-2.5">
        {zones.map((zone, i) => (
          <li
            key={zone}
            className="hs-rise rounded-2xl border border-border bg-card/80 px-3.5 py-3"
            style={rang(i + 1)}
          >
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">{zone}</span>
              <span className="font-mono text-foreground">— cm</span>
            </div>
            <div className="hs-regle mt-2.5" style={rang(i)} aria-hidden>
              <span className="hs-regle__curseur" />
            </div>
          </li>
        ))}
      </ul>
      <div className="mt-4 flex flex-wrap gap-2">
        {[tm("stage.layers"), tm("stage.preference")].map((libelle, i) => (
          <span
            key={libelle}
            className="hs-rise rounded-full border border-border px-3 py-1.5 text-xs text-muted-foreground"
            style={rang(i + 5)}
          >
            {libelle}
          </span>
        ))}
      </div>
    </>
  );
}

/* 04 : l'analyse. Dessin technique de la pièce, cotes zone par zone, puis
   convergence vers une bande de tailles. Illustration, non résultat. */
export function SceneAnalyse({ t, tm }: { t: T; tm: TM }) {
  const cotes = [
    { y: 70, libelle: t("zones.c.label") },
    { y: 122, libelle: t("zones.wa.label") },
    { y: 176, libelle: t("zones.hp.label") },
  ];
  const tailles = ["XS", "S", "M", "L", "XL"];
  return (
    <>
      <Legende numero="03" texte={tm("hero.titres.t5")} />
      <div className="relative">
        <svg
          viewBox="0 0 300 210"
          className="w-full text-primary"
          fill="none"
          stroke="currentColor"
          strokeLinecap="round"
          strokeLinejoin="round"
          focusable="false"
        >
          <path
            className="hs-trace"
            pathLength={1}
            strokeWidth={1.5}
            style={rang(0)}
            d="M118 22 L150 14 L182 22 L214 40 L240 152 L216 158 L200 92 L200 194 L100 194 L100 92 L84 158 L60 152 L86 40 Z"
          />
          <path
            className="hs-trace"
            pathLength={1}
            strokeWidth={1}
            style={rang(2)}
            d="M150 16 L150 194"
            strokeDasharray="1"
            opacity={0.35}
          />
          {cotes.map((c, i) => (
            <g key={c.libelle}>
              <path
                className="hs-trace"
                pathLength={1}
                strokeWidth={1}
                style={rang(i + 3)}
                d={`M92 ${c.y} H208 M92 ${c.y - 4} V${c.y + 4} M208 ${c.y - 4} V${c.y + 4}`}
              />
              <text
                className="hs-rise"
                style={rang(i + 4)}
                x={252}
                y={c.y + 3}
                fontSize={9}
                fill="currentColor"
                stroke="none"
                fontFamily="var(--font-mono)"
              >
                0{i + 1}
              </text>
            </g>
          ))}
        </svg>
        <span className="hs-balayage" aria-hidden />
      </div>
      <div className="mt-3 grid grid-cols-5 gap-1.5" aria-hidden>
        {tailles.map((taille) => (
          <span
            key={taille}
            className="hs-case rounded-lg border border-border py-1.5 text-center font-mono text-xs text-muted-foreground"
            data-cible={taille === "M" ? "" : undefined}
          >
            {taille}
          </span>
        ))}
      </div>
      <p
        className="hs-rise mt-3 font-mono text-[0.6875rem] uppercase tracking-wide text-muted-foreground"
        style={rang(9)}
      >
        {tm("stage.illustration")}
      </p>
    </>
  );
}

/* 05 : la vraie interface (carte de résultat existante). */
export function SceneResultat({ t, tm }: { t: T; tm: TM }) {
  return (
    <>
      <Legende numero="04" texte={tm("comment.s4t")} />
      <div className="hs-arrivee">
        <CadrePhone label={tm("hero.mockAria")}>
          <CarteResultatDemo t={t} />
        </CadrePhone>
      </div>
      <p className="mt-3 text-center font-mono text-[0.6875rem] uppercase tracking-wide text-muted-foreground">
        {tm("stage.illustration")}
      </p>
    </>
  );
}
