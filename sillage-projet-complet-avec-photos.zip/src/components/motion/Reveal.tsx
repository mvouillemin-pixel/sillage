import {
  createElement,
  useEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";

import { MARGE_REVELATION, SEUIL_REVELATION, useReducedMotion } from "@/lib/motion";

type Balise = "div" | "section" | "article" | "ul" | "ol" | "li" | "p" | "span" | "figure";

/* Trois états :
   - "repos"  : rendu serveur et premier rendu client, contenu pleinement visible ;
   - "cache"  : armé après l'hydratation, uniquement si l'élément est sous la
                ligne de flottaison et que le mouvement est autorisé ;
   - "visible": révélé à l'entrée dans la fenêtre.
   Sans JavaScript, avec IntersectionObserver absent ou avec « réduire les
   animations », l'élément reste en "repos" : le contenu n'est jamais masqué. */
type Etat = "repos" | "cache" | "visible";

export function Reveal({
  as = "div",
  delay = 0,
  className,
  children,
}: {
  as?: Balise;
  /** Décalage en ms, pour échelonner plusieurs éléments voisins. */
  delay?: number;
  className?: string;
  children: ReactNode;
}) {
  const reduit = useReducedMotion();
  const ref = useRef<HTMLElement | null>(null);
  const [etat, setEtat] = useState<Etat>("repos");

  useEffect(() => {
    const el = ref.current;
    if (!el || reduit || typeof IntersectionObserver === "undefined") {
      setEtat("repos");
      return;
    }
    // Déjà à l'écran au chargement : aucune animation, aucun clignotement.
    if (el.getBoundingClientRect().top < window.innerHeight) return;

    setEtat("cache");
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setEtat("visible");
          observer.disconnect();
        }
      },
      { threshold: SEUIL_REVELATION, rootMargin: MARGE_REVELATION },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [reduit]);

  return createElement(
    as,
    {
      ref,
      className: `reveal${className ? ` ${className}` : ""}`,
      "data-reveal": etat,
      style: delay ? ({ "--reveal-delay": `${delay}ms` } as CSSProperties) : undefined,
    },
    children,
  );
}
