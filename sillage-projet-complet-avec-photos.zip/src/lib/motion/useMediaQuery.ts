import { useSyncExternalStore } from "react";

/** Suit une media query. Rendu serveur : `false`. */
export function useMediaQuery(requete: string): boolean {
  return useSyncExternalStore(
    (onChange) => {
      const mql = window.matchMedia(requete);
      mql.addEventListener("change", onChange);
      return () => mql.removeEventListener("change", onChange);
    },
    () => window.matchMedia(requete).matches,
    () => false,
  );
}
