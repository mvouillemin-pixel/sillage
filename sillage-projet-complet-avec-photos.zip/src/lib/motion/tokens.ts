/* Tokens de motion SILLAGE.
   Miroir TypeScript des variables CSS de styles.css (--ease-*, --duree-*),
   pour les animations pilotées en JavaScript (Web Animations API).
   Toute modification de valeur doit être faite aux deux endroits. */

export const EASE = {
  apparition: "cubic-bezier(0.22, 1, 0.36, 1)",
  etat: "cubic-bezier(0.65, 0, 0.35, 1)",
} as const;

/** Durées en millisecondes. */
export const DUREE = {
  etat: 420,
  apparition: 520,
  fondu: 150,
} as const;

/** Décalage entre deux éléments d'une séquence (stagger), en millisecondes. */
export const STAGGER = 80;

/** Part de l'élément qui doit être visible avant de déclencher une révélation. */
export const SEUIL_REVELATION = 0.15;

/** Marge basse : la révélation démarre légèrement avant l'entrée complète. */
export const MARGE_REVELATION = "0px 0px -8% 0px";

/** Largeur (px) sous laquelle l'expérience mobile s'applique. */
export const BREAKPOINT_MOBILE = 768;
