import { useSyncExternalStore } from "react";

const REQUETE = "(prefers-reduced-motion: reduce)";

function subscribe(onChange: () => void) {
  const mql = window.matchMedia(REQUETE);
  mql.addEventListener("change", onChange);
  return () => mql.removeEventListener("change", onChange);
}

const lireClient = () => window.matchMedia(REQUETE).matches;

/* Rendu serveur : on suppose le mouvement autorisé. Le contenu est de toute façon
   visible sans JavaScript ; la préférence réelle prend le relais à l'hydratation. */
const lireServeur = () => false;

/** `true` quand l'utilisateur demande à réduire les animations. */
export function useReducedMotion(): boolean {
  return useSyncExternalStore(subscribe, lireClient, lireServeur);
}
