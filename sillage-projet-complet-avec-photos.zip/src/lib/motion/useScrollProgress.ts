import { useEffect, type RefObject } from "react";

/** Écrit la progression de défilement d'un élément dans sa variable CSS `--p` (0 à 1).
    0 quand le haut de l'élément atteint le bas de l'écran, 1 quand son bas atteint
    le milieu de l'écran. Aucun rendu React : une seule lecture de mise en page par
    image, écrite en variable CSS. Sans mouvement (`actif = false`) : `--p` vaut 1. */
export function useScrollProgress<T extends HTMLElement>(ref: RefObject<T | null>, actif: boolean) {
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (!actif) {
      el.style.setProperty("--p", "1");
      return;
    }

    let image = 0;
    const calculer = () => {
      image = 0;
      const r = el.getBoundingClientRect();
      const debut = window.innerHeight;
      const fin = window.innerHeight * 0.5 - r.height;
      const p = (debut - r.top) / (debut - fin);
      el.style.setProperty("--p", Math.min(1, Math.max(0, p)).toFixed(3));
    };
    const demander = () => {
      if (!image) image = window.requestAnimationFrame(calculer);
    };

    calculer();
    window.addEventListener("scroll", demander, { passive: true });
    window.addEventListener("resize", demander);
    return () => {
      window.cancelAnimationFrame(image);
      window.removeEventListener("scroll", demander);
      window.removeEventListener("resize", demander);
    };
  }, [ref, actif]);
}
