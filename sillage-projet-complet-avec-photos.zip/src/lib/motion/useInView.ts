import { useEffect, useRef, useState } from "react";

import { MARGE_REVELATION, SEUIL_REVELATION } from "./tokens";

/** Observe l'entrée d'un élément dans la fenêtre. Sans IntersectionObserver, renvoie `true`. */
export function useInView<T extends Element = HTMLElement>(options?: {
  /** Ne signale l'entrée qu'une seule fois, puis cesse d'observer. */
  once?: boolean;
  threshold?: number;
  rootMargin?: string;
}) {
  const {
    once = true,
    threshold = SEUIL_REVELATION,
    rootMargin = MARGE_REVELATION,
  } = options ?? {};
  const ref = useRef<T | null>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      setInView(true);
      return;
    }
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setInView(true);
          if (once) observer.disconnect();
        } else if (!once) {
          setInView(false);
        }
      },
      { threshold, rootMargin },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [once, threshold, rootMargin]);

  return { ref, inView };
}
