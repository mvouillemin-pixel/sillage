import { useCallback, useEffect, useState } from "react";

/** Séquence de scènes chronométrées.
    `index` va de 0 à `durees.length` ; la dernière valeur est l'état final, stable.
    Le chronomètre se met en pause quand l'onglet est masqué et redémarre la scène
    courante à son retour. `actif = false` place directement la séquence à sa fin. */
export function useSequence(durees: readonly number[], actif: boolean) {
  const fin = durees.length;
  const [position, setPosition] = useState(0);
  const index = actif ? Math.min(position, fin) : fin;

  useEffect(() => {
    if (!actif || position >= fin) return;
    let minuteur: number | undefined;
    const arreter = () => window.clearTimeout(minuteur);
    const demarrer = () => {
      arreter();
      minuteur = window.setTimeout(() => setPosition((p) => p + 1), durees[position]);
    };
    const surVisibilite = () => (document.hidden ? arreter() : demarrer());

    if (!document.hidden) demarrer();
    document.addEventListener("visibilitychange", surVisibilite);
    return () => {
      arreter();
      document.removeEventListener("visibilitychange", surVisibilite);
    };
  }, [position, actif, fin, durees]);

  const passer = useCallback(() => setPosition(fin), [fin]);
  const rejouer = useCallback(() => setPosition(0), []);

  return { index, fin, termine: index >= fin, passer, rejouer };
}
