# Motion SILLAGE

Système de motion de la page d'accueil. Aucune dépendance : CSS, `IntersectionObserver` et
timers. Tout est en `opacity` et `transform`.

## Règles

- **Le contenu n'est jamais masqué.** Rendu serveur, sans JavaScript et avec
  `prefers-reduced-motion`, chaque texte, lien et bouton est visible.
- **`prefers-reduced-motion`** : CSS (`@media`) et JS (`useReducedMotion`) doivent tous deux
  couper l'animation. Toute nouvelle animation ajoute sa règle dans le bloc « reduce ».
- **Contraste** : ne jamais estomper du texte avec `opacity` (WCAG AA, 4,5:1).
- **Pas de détournement du scroll**, pas d'épinglage long ; sur mobile, mouvement réduit.
- **Textes** : dictionnaires existants (`marketing-i18n.ts`). Nouveaux textes en EN et FR ;
  les autres langues retombent sur l'anglais.

## Où est quoi

| Fichier                                                  | Rôle                                                         |
| -------------------------------------------------------- | ------------------------------------------------------------ |
| `src/lib/motion/tokens.ts`                               | Durées et courbes (miroir des variables CSS de `styles.css`) |
| `src/lib/motion/useReducedMotion.ts`, `useMediaQuery.ts` | Préférences, SSR-safe                                        |
| `src/lib/motion/useInView.ts`, `useScrollProgress.ts`    | Entrée à l'écran, progression du scroll (`--p`)              |
| `src/lib/motion/useSequence.ts`                          | Scènes chronométrées, pause quand l'onglet est masqué        |
| `src/components/motion/Reveal.tsx`                       | Révélation au scroll                                         |
| `src/components/marketing/hero/`                         | Séquence d'ouverture (`HeroStage`, `scenes`, CSS)            |
| `src/components/marketing/story/`                        | « How it works » guidé par le scroll                         |
| `src/components/marketing/sports/`                       | « What do you want to start? »                               |
| `src/lib/sillage/accueil-sports.ts`                      | États des sports sur l'accueil (lecture seule du catalogue)  |

## États des sports

Seuls le ski et le snowboard sont « Disponible ». Les sports listés dans `NON_ANNONCES`
(néoprène) restent « En développement » tant que la feuille de route (bêta néoprène
printemps 2027) et le catalogue ne sont pas alignés. Un sport non disponible ne mène jamais
à l'outil de taille.

## Vérifier

```sh
bun run build && npx tsc --noEmit
```

Accessibilité : `axe-core` est en devDependency ; l'injecter sur la page et lancer
`axe.run` (tags wcag2a, wcag2aa, wcag21a, wcag21aa, best-practice).
