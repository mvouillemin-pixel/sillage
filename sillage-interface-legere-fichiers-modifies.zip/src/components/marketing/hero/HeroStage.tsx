import { RotateCcw, SkipForward } from "lucide-react";
import { useEffect, useRef } from "react";

import { useMediaQuery, useReducedMotion, useSequence } from "@/lib/motion";
import type { T } from "@/lib/sillage/i18n";
import type { TM } from "@/lib/sillage/marketing-i18n";

import "./hero-stage.css";
import "./hero-orbits.css";
import {
  Scene,
  SceneAnalyse,
  SceneQuestion,
  SceneResultat,
  SceneSport,
  SceneVous,
  type EtatScene,
} from "./scenes";

/* Durées (ms) des quatre premières scènes ; la cinquième est l'état final.
   Bureau ≈ 13 s, mobile ≈ 9 s : moins de temps, mêmes scènes, aucun épinglage de scroll. */
const DUREES_BUREAU = [3000, 3300, 3300, 3400] as const;
const DUREES_MOBILE = [2200, 2400, 2400, 2400] as const;

/** Scène d'ouverture : « What do you want to start? » → un sport → vous → analyse → interface.
    Rendu serveur : première scène, statique et complète. Avec « réduire les animations »,
    l'état final s'affiche directement (aussi par CSS, avant hydratation). */
export function HeroStage({
  t,
  tm,
  onTermine,
}: {
  t: T;
  tm: TM;
  /** Appelé une fois quand la séquence atteint son état final en jouant. */
  onTermine?: (termine: boolean) => void;
}) {
  const reduit = useReducedMotion();
  const mobile = useMediaQuery("(max-width: 767px)");
  const durees = mobile ? DUREES_MOBILE : DUREES_BUREAU;
  const { index, fin, termine, passer, rejouer } = useSequence(durees, !reduit);

  const dernier = useRef(termine);
  useEffect(() => {
    if (dernier.current !== termine) {
      dernier.current = termine;
      onTermine?.(termine);
    }
  }, [termine, onTermine]);

  const etat = (i: number): EtatScene => (i === index ? "active" : i < index ? "past" : "idle");

  return (
    <div>
      <div role="img" aria-label={tm("stage.aria")} className="hs">
        <Scene etat={etat(0)}>
          <SceneQuestion tm={tm} />
        </Scene>
        <Scene etat={etat(1)}>
          <SceneSport tm={tm} />
        </Scene>
        <Scene etat={etat(2)}>
          <SceneVous t={t} tm={tm} />
        </Scene>
        <Scene etat={etat(3)}>
          <SceneAnalyse t={t} tm={tm} />
        </Scene>
        <Scene etat={etat(4)} finale>
          <SceneResultat t={t} tm={tm} />
        </Scene>
      </div>

      <div className="hs-commandes mt-4 flex items-center justify-between gap-4">
        <div className="hs-progression flex flex-1 gap-1.5" aria-hidden>
          {Array.from({ length: fin + 1 }, (_, i) => (
            <span
              key={i}
              className="hs-segment"
              data-etat={etat(i)}
              style={{ "--d": `${durees[i] ?? 0}ms` } as React.CSSProperties}
            />
          ))}
        </div>
        {termine ? (
          <button type="button" onClick={rejouer} className="hs-bouton">
            <RotateCcw className="size-4" aria-hidden />
            {tm("stage.replay")}
          </button>
        ) : (
          <button type="button" onClick={passer} className="hs-bouton">
            <SkipForward className="size-4" aria-hidden />
            {tm("stage.skip")}
          </button>
        )}
      </div>
    </div>
  );
}
