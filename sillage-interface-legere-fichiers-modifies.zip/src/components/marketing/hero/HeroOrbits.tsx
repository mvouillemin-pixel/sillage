/* Orbites 3D légères derrière la séquence d'ouverture : des anneaux inclinés en
   perspective (CSS 3D, sans librairie) qui tournent lentement, avec un point qui
   trace le « sillage ». Décoratif : masqué aux lecteurs d'écran, absent sur mobile,
   figé avec « réduire les animations ». Uniquement des transformations. */

import type { CSSProperties } from "react";

const ANNEAUX = [
  { taille: 100, duree: 90, sens: 1, depart: 0 },
  { taille: 76, duree: 66, sens: -1, depart: 90 },
  { taille: 54, duree: 48, sens: 1, depart: 210 },
] as const;

export function HeroOrbits() {
  return (
    <div className="ho" aria-hidden>
      {ANNEAUX.map((a) => (
        <div
          key={a.taille}
          className="ho-anneau"
          style={
            {
              "--t": `${a.taille}%`,
              "--d": `${a.duree}s`,
              "--s": a.sens,
              "--a": `${a.depart}deg`,
            } as CSSProperties
          }
        >
          <span className="ho-point" />
        </div>
      ))}
    </div>
  );
}
