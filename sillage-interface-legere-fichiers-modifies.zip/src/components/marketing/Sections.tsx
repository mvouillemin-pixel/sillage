import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";

import { BlocNonEvalue } from "@/components/marketing/Cadres";
import { FormulaireAccesAnticipe, FormulaireContact } from "@/components/marketing/Formulaires";
import { HeroOrbits } from "@/components/marketing/hero/HeroOrbits";
import { HeroStage } from "@/components/marketing/hero/HeroStage";
import { Reveal } from "@/components/motion/Reveal";
import { CommentStory } from "@/components/marketing/story/CommentStory";
import type { Lang, T } from "@/lib/sillage/i18n";
import { CHEMIN_BUSINESS, type LangBusiness } from "@/lib/sillage/business-i18n";
import type { TM } from "@/lib/sillage/marketing-i18n";

/** Section pleine largeur, contenu contenu à 1120 px. */
export function Section({
  id,
  children,
  ton = "clair",
}: {
  id: string;
  children: ReactNode;
  ton?: "clair" | "menthe";
}) {
  return (
    <section id={id} className={`w-full scroll-mt-20 ${ton === "menthe" ? "bg-mint/25" : ""}`}>
      <div className="mx-auto w-full max-w-[1120px] px-5 py-24 md:py-36">{children}</div>
    </section>
  );
}

/** Titre de section : apparaît en douceur au défilement. */
export function EnTete({ eyebrow, titre }: { eyebrow: string; titre: string }) {
  return (
    <Reveal>
      <p className="eyebrow">{eyebrow}</p>
      <h2 className="mt-4 max-w-2xl font-serif text-3xl leading-tight text-foreground md:text-4xl">
        {titre}
      </h2>
    </Reveal>
  );
}

/** Carte allégée : un simple filet, sans cadre ni fond. */
function Carte({ titre, texte, delai = 0 }: { titre: string; texte: string; delai?: number }) {
  return (
    <Reveal delay={delai} className="border-t border-border pt-6">
      <h3 className="font-serif text-lg text-foreground">{titre}</h3>
      <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{texte}</p>
    </Reveal>
  );
}

export function Hero({ lang, t, tm }: { lang: Lang; t: T; tm: TM }) {
  /* Vrai quand la séquence d'ouverture vient de se terminer : le CTA le confirme. */
  const [fini, setFini] = useState(false);

  /* Mobile : texte et CTA d'abord, puis la séquence, puis le formulaire.
     Bureau : texte et formulaire à gauche, la séquence sur toute la hauteur à droite. */
  return (
    <Section id="hero">
      <div className="grid items-center gap-x-16 gap-y-12 md:grid-cols-2 md:gap-y-8">
        <div className="grid gap-7 md:col-start-1 md:row-start-1 md:self-end">
          <p className="eyebrow text-primary">{tm("hero.positions.p2")}</p>
          <h1 className="font-serif text-4xl leading-tight text-foreground md:text-5xl">
            <span className="apparition">{tm("hero.titres.t1")}</span>
          </h1>
          <p className="max-w-xl leading-relaxed text-muted-foreground">{tm("hero.sous")}</p>
          <div>
            <Link
              to="/app"
              data-fini={fini}
              className="hero-cta btn-primaire inline-flex min-h-11 items-center rounded-[24px] bg-primary px-6 py-3 text-sm font-medium text-primary-foreground"
            >
              {tm("hero.ctas.c1")}
            </Link>
          </div>
        </div>
        <div className="relative md:col-start-2 md:row-span-2 md:row-start-1 md:self-start">
          <HeroOrbits />
          <div className="relative z-10">
            <HeroStage t={t} tm={tm} onTermine={setFini} />
          </div>
        </div>
        <div className="md:col-start-1 md:row-start-2 md:self-start">
          {/* Formulaire replié : le hero reste léger, l'inscription reste à un clic. */}
          <details className="acces-details max-w-md">
            <summary className="inline-flex min-h-11 cursor-pointer items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
              {tm("wait.titre")}
            </summary>
            <div className="pt-3">
              <FormulaireAccesAnticipe lang={lang} tm={tm} />
            </div>
          </details>
        </div>
      </div>
    </Section>
  );
}

export function Probleme({ tm }: { tm: TM }) {
  return (
    <Section id="probleme">
      <EnTete eyebrow={tm("probleme.eyebrow")} titre={tm("probleme.titre")} />
      <div className="mt-14 grid gap-10 md:grid-cols-3 md:gap-12">
        <Carte titre={tm("probleme.c1t")} texte={tm("probleme.c1d")} />
        <Carte titre={tm("probleme.c2t")} texte={tm("probleme.c2d")} delai={80} />
        <Carte titre={tm("probleme.c3t")} texte={tm("probleme.c3d")} delai={160} />
      </div>
    </Section>
  );
}

export function Comment({ t, tm }: { t: T; tm: TM }) {
  return (
    <Section id="comment">
      <EnTete eyebrow={tm("comment.eyebrow")} titre={tm("comment.titre")} />
      <CommentStory t={t} tm={tm} />
    </Section>
  );
}

export function Honnetete({ t, tm }: { t: T; tm: TM }) {
  return (
    <Section id="honnetete" ton="menthe">
      <p className="eyebrow">{tm("honnete.eyebrow")}</p>
      <p className="mt-4 max-w-3xl font-serif text-2xl leading-snug text-foreground md:text-3xl">
        {tm("honnete.phrase")}
      </p>
      <div className="mt-12 max-w-xl rounded-2xl bg-card/70 p-6">
        <p className="text-sm text-muted-foreground">{tm("honnete.exemple")}</p>
        <div className="mt-4">
          <BlocNonEvalue t={t} />
        </div>
      </div>
      <p className="mt-6 max-w-xl text-sm text-muted-foreground">{tm("honnete.sous")}</p>
    </Section>
  );
}

export function Disciplines({ tm }: { tm: TM }) {
  const lignes = [
    { nom: tm("disc.neo"), etat: tm("disc.neoEtat") },
    { nom: tm("disc.ski"), etat: tm("disc.skiEtat") },
    { nom: tm("disc.harn"), etat: tm("disc.harnEtat") },
  ];
  return (
    <Section id="disciplines">
      <EnTete eyebrow={tm("disc.eyebrow")} titre={tm("disc.titre")} />
      <ul className="mt-14 grid gap-10 md:grid-cols-3 md:gap-12">
        {lignes.map((l, i) => (
          <Reveal as="li" key={l.nom} delay={i * 80} className="border-t border-border pt-6">
            <p className="font-serif text-lg text-foreground">{l.nom}</p>
            <p className="mt-2 font-mono text-xs uppercase tracking-wide text-muted-foreground">{l.etat}</p>
          </Reveal>
        ))}
      </ul>
    </Section>
  );
}

export function TeaserPro({ tm, lang }: { tm: TM; lang: Lang }) {
  /* La page entreprises existe par langue : le lien suit la langue active. */
  const lienBusiness = (CHEMIN_BUSINESS[lang as LangBusiness] ??
    "/en/for-business") as "/en/for-business";
  return (
    <Section id="pro">
      <Reveal className="rounded-3xl bg-card/60 p-8 md:p-14">
        <p className="eyebrow">{tm("pros.eyebrow")}</p>
        <h2 className="mt-4 font-serif text-3xl text-foreground md:text-4xl">{tm("pros.titre")}</h2>
        <p className="mt-5 max-w-2xl leading-relaxed text-muted-foreground">{tm("pros.texte")}</p>
        <Link
          to={lienBusiness}
          className="btn-contour mt-8 inline-flex min-h-11 items-center rounded-[24px] border border-primary px-5 py-2.5 text-sm font-medium text-primary"
        >
          {tm("pros.cta")}
        </Link>
      </Reveal>
    </Section>
  );
}

export function Roadmap({ tm }: { tm: TM }) {
  const jalons = [
    { d: tm("road.m1d"), l: tm("road.m1") },
    { d: tm("road.m2d"), l: tm("road.m2") },
    { d: tm("road.m3d"), l: tm("road.m3") },
    { d: tm("road.m4d"), l: tm("road.m4") },
  ];
  return (
    <Section id="roadmap">
      <EnTete eyebrow={tm("road.eyebrow")} titre={tm("road.titre")} />
      <ol className="mt-14 grid max-w-2xl gap-0 border-l border-border pl-6">
        {jalons.map((j, i) => (
          <Reveal as="li" key={j.l} delay={i * 80} className="relative py-5">
            <span className="absolute -left-[1.68rem] top-7 size-2.5 rounded-full bg-primary" aria-hidden />
            <p className="font-mono text-xs uppercase tracking-wide text-muted-foreground">{j.d}</p>
            <p className="mt-1 text-foreground">{j.l}</p>
          </Reveal>
        ))}
      </ol>
      <p className="mt-6 text-sm italic text-muted-foreground">{tm("road.avertissement")}</p>
    </Section>
  );
}

export function Confidentialite({ tm }: { tm: TM }) {
  const cartes = [
    { t: tm("privacy.c1t"), d: tm("privacy.c1d") },
    { t: tm("privacy.c2t"), d: tm("privacy.c2d") },
    { t: tm("privacy.c3t"), d: tm("privacy.c3d") },
    { t: tm("privacy.c4t"), d: tm("privacy.c4d") },
  ];
  return (
    <Section id="privacy" ton="menthe">
      <EnTete eyebrow={tm("privacy.eyebrow")} titre={tm("privacy.titre")} />
      <div className="mt-14 grid gap-10 sm:grid-cols-2 lg:grid-cols-4 lg:gap-8">
        {cartes.map((c, i) => (
          <Carte key={c.t} titre={c.t} texte={c.d} delai={i * 80} />
        ))}
      </div>
    </Section>
  );
}

export function Contact({ lang, tm }: { lang: Lang; tm: TM }) {
  return (
    <Section id="contact">
      <EnTete eyebrow={tm("contact.eyebrow")} titre={tm("contact.titre")} />
      <div className="mt-14 max-w-2xl">
        <FormulaireContact lang={lang} tm={tm} />
      </div>
    </Section>
  );
}
